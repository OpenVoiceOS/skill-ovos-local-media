# <img src='https://raw.githubusercontent.com/FortAwesome/Font-Awesome/6.x/svgs/solid/folder-open.svg' card_color='#55dffe' width='50' height='50' style='vertical-align:bottom'/> File Browser

## About
File Browser For Open Voice OS

## Examples
* "Open File Browser"
* "Show File Browser"

## Credits
Aditya Mehra (@AIIX)

## Category
**Daily**

## Tags
#filebrowser
#browser
#file
#manager
#local
#usb

## Notes
- File Browser requires latest OVOS Shell: https://github.com/OpenVoiceOS/ovos-shell
- Not backwards compatible with Mycroft-Core GUI API, Requires OVOS QML Plugin from ovos-shell
